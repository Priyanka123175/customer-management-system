const logoutBtn = document.getElementById("logoutBtn");
const themeToggle = document.getElementById("themeToggle");
const searchBtn = document.getElementById("searchBtn");
const tableBody = document.querySelector("#custTable tbody");

// Redirect if not logged in
if (localStorage.getItem("isLoggedIn") !== "true") {
  window.location.href = "index.html";
}

// Load all customers
function loadCustomers() {
  const customers = JSON.parse(localStorage.getItem("customers")) || [];
  tableBody.innerHTML = "";
  customers.forEach(c => {
    tableBody.innerHTML += `
      <tr>
        <td>${c.id}</td>
        <td>${c.name}</td>
        <td>${c.phone}</td>
        <td>${c.email}</td>
      </tr>`;
  });
}
loadCustomers();

// Search customer
searchBtn.addEventListener("click", () => {
  const id = document.getElementById("searchId").value.trim();
  const customers = JSON.parse(localStorage.getItem("customers")) || [];
  const found = customers.find(c => c.id == id);

  if (found) {
    alert(`✅ Customer Found!\n\nName: ${found.name}\nPhone: ${found.phone}\nEmail: ${found.email}`);
  } else {
    alert("❌ Customer not found!");
  }
});

// Logout
logoutBtn.addEventListener("click", () => {
  localStorage.removeItem("isLoggedIn");
  window.location.href = "index.html";
});

// Theme toggle
themeToggle.addEventListener("click", () => {
  const body = document.body;
  body.classList.toggle("light");
  body.classList.toggle("dark");
  const theme = body.classList.contains("light") ? "light" : "dark";
  localStorage.setItem("theme", theme);
  themeToggle.textContent = theme === "light" ? "🌞 Light Mode" : "🌙 Dark Mode";
});

window.onload = () => {
  const savedTheme = localStorage.getItem("theme") || "dark";
  document.body.classList.add(savedTheme);
  themeToggle.textContent = savedTheme === "light" ? "🌞 Light Mode" : "🌙 Dark Mode";
};
